/**
 * Created By : TheCoachSMB - Sonal Motghare-Balpande
 */
var config = {
    paths: {
        owlcarousel: "Tech9logy_Tathastu/js/owl.carousel"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};