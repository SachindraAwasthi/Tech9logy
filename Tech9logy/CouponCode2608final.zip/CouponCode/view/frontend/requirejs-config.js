var config = {
    map: {
        '*': {
            couponcode: 'Tech9logy_CouponCode/js/newsletter'
        }
    }
};
